<?php

/**
 * Created by PhpStorm.
 * User: professor
 * Date: 8/31/2015
 * Time: 10:27 AM
 */
final class hawk_error
{

    public static function showError($message)
    {
        echo $message;
    }

    public static function showSuccess($message)
    {
        echo $message;
    }
}